/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import LandingPage from './pages/LandingPage';
import DashboardLayout from './components/layout/DashboardLayout';
import Inbox from './pages/dashboard/Inbox';
import Training from './pages/dashboard/Training';

import { NotificationProvider } from './context/NotificationContext';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  return (
    <NotificationProvider>
      <Router>
        <div className="min-h-screen bg-bg-dark text-white selection:bg-brand-primary selection:text-bg-dark">
          <ScrollToTop />
          <Routes>
            <Route path="/" element={<LandingPage />} />
            
            {/* Dashboard Routes */}
            <Route path="/dashboard" element={<DashboardLayout />}>
              <Route index element={<Navigate to="/dashboard/inbox" replace />} />
              <Route path="inbox" element={<Inbox />} />
              <Route path="training" element={<Training />} />
            </Route>
  
            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </Router>
    </NotificationProvider>
  );
}
